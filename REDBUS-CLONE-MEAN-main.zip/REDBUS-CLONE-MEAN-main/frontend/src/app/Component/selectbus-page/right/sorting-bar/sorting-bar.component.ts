import { Component } from '@angular/core';

@Component({
  selector: 'app-sorting-bar',
  templateUrl: './sorting-bar.component.html',
  styleUrl: './sorting-bar.component.css'
})
export class SortingBarComponent {

}
